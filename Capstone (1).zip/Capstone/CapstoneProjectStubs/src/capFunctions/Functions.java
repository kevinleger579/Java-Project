package capFunctions;

public class Functions {

	public Functions() {

	}

	public String FindCharWithinStringName(string, int) {
		// Use the charAt function to return a character within a string name at a
		// location index
		return null;

	}

	public int CompareTwoStrings(string, string) {
		// Use parseint to compare 2 strings
		// return 0 if the strings are equal, a positive number if string 1 is greater
		// than string 2, a negative number if string 2 is greater than string 1

		return 0;

	}

	public boolean ContainsIncludedString(string, string) {
		// use the contains function to can return true if the string name exactly
		// contains the
		// included string, and false otherwise
		return false;

	}

	public String ConvertStringtoLowercase(string) {
		// Use toLowercase function to return a string with only lowercase letters
		return null;

	}

	public String ConvertIntToString(integer) {
		// use toString method to return a string that contains the characters that
		// correspond to the digits in the number

		return null;

	}

	public boolean CheckIfStringsAreTheSame(string, string) {
		// use equals functions to return true if stringName is identical to
		// otherStringName and false if stringName is not identical to otherStringName
		return false;

	}

	public int FindFirstOccurOfSubString(string, string) {
		//use find function to return the numeric location in the equivalent char array 
		//of the first time the included string appears in the string name 

		return 0;

	}

	public int FindLastOccurOfSubString(string, string) {
		//use rfind function to return the numeric location in the equivalent char array 
		//of the last time the included string appears in the string name
		return 0;

	}

	public int FindLengthOfString(string) {
		//use the length function to find the length of the string
		return 0;

	}

	public String Substring(string, int, int) {
		//create an array that is the length of my string in order for the first 
		//character to be throughout the entire array
		return null;

	}
}
