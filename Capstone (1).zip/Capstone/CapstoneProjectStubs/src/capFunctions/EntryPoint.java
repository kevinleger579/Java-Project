package capFunctions;

public class EntryPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Functions();
	}

}
